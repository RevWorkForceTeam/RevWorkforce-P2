import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { NotificationService } from '../../../core/services/notification.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, SidebarComponent],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications = signal<any[]>([]);
  isLoading = signal(true);

  constructor(
    private notificationService: NotificationService,
    public auth: AuthService
  ) {}

  ngOnInit() {
    this.notificationService.getMyNotifications().subscribe({
      next: (data) => {
        this.notifications.set(data);
        this.isLoading.set(false);
      },
      error: () => {
        this.notifications.set([
          { id: 1, message: 'Your <strong>Sick Leave</strong> has been <strong style="color:#059669">approved</strong>.', createdAt: '2 hours ago', isRead: false, type: 'LEAVE' },
          { id: 2, message: 'Manager provided <strong>feedback</strong> on your Q4 Performance Review.', createdAt: 'Yesterday', isRead: false, type: 'PERFORMANCE' },
          { id: 3, message: 'New announcement: <strong>Office Holiday – Holi</strong>', createdAt: '2 days ago', isRead: false, type: 'ANNOUNCEMENT' },
          { id: 4, message: 'Your <strong>Casual Leave</strong> was <strong style="color:#dc2626">rejected</strong>.', createdAt: '1 week ago', isRead: true, type: 'LEAVE' }
        ]);
        this.isLoading.set(false);
      }
    });
  }

  markAsRead(id: number) {
    this.notificationService.markAsRead(id).subscribe({
      next: () => this.notifications.update(list => list.map(n => n.id === id ? {...n, isRead: true} : n)),
      error: () => {}
    });
  }

  markAllAsRead() {
    this.notificationService.markAllAsRead().subscribe({
      next: () => this.notifications.update(list => list.map(n => ({...n, isRead: true}))),
      error: () => {}
    });
  }

  getInitials(name: string | undefined): string {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }

  getRole(): 'EMPLOYEE' | 'MANAGER' | 'ADMIN' {
    const role = this.auth.getRole();
    return (role === 'EMPLOYEE' || role === 'MANAGER' || role === 'ADMIN') ? role : 'EMPLOYEE';
  }
}
