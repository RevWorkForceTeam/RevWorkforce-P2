import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { AuthService } from '../../../core/services/auth.service';
import { LeaveService } from '../../../core/services/leave.service';

interface Holiday {
  id: number;
  name: string;
  date: string;
  day: string;
  type: string;
}

@Component({
  selector: 'app-holiday-calendar',
  standalone: true,
  imports: [CommonModule, SidebarComponent],
  templateUrl: './holiday-calendar.component.html',
  styleUrl: './holiday-calendar.component.css'
})
export class HolidayCalendarComponent implements OnInit {
  holidays = signal<Holiday[]>([]);
  isLoading = signal(true);

  constructor(public auth: AuthService, private leaveService: LeaveService) {}

  ngOnInit() {
    this.leaveService.getAllHolidays().subscribe({
      next: (data: any[]) => {
        this.holidays.set(data.map(h => ({
          id: h.id,
          name: h.name,
          date: h.date,
          day: new Date(h.date).toLocaleDateString('en-US', { weekday: 'long' }),
          type: h.type || 'Holiday'
        })));
        this.isLoading.set(false);
      },
      error: () => {
        this.holidays.set([
          { id: 1, name: 'Republic Day', date: '2026-01-26', day: 'Monday', type: 'National Holiday' },
          { id: 2, name: 'Holi', date: '2026-03-14', day: 'Saturday', type: 'Festival' },
          { id: 3, name: 'Good Friday', date: '2026-04-03', day: 'Friday', type: 'Religious' },
          { id: 4, name: 'Independence Day', date: '2026-08-15', day: 'Saturday', type: 'National Holiday' },
          { id: 5, name: 'Gandhi Jayanti', date: '2026-10-02', day: 'Friday', type: 'National Holiday' },
          { id: 6, name: 'Diwali', date: '2026-10-19', day: 'Monday', type: 'Festival' },
          { id: 7, name: 'Christmas', date: '2026-12-25', day: 'Friday', type: 'Religious' }
        ]);
        this.isLoading.set(false);
      }
    });
  }

  getInitials(name: string | undefined): string {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
}
