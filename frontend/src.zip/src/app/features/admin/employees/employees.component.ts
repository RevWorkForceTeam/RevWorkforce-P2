import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { EmployeeService } from '../../../core/services/employee.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [CommonModule, FormsModule, SidebarComponent],
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  employees = signal<any[]>([]);
  filteredEmployees = signal<any[]>([]);
  departments = signal<any[]>([]);
  designations = signal<any[]>([]);
  isLoading = signal(true);
  showAddModal = signal(false);
  searchTerm = '';
  
  newEmployee = {
    firstName: '', lastName: '', email: '', password: '', employeeId: '', 
    departmentId: undefined, designationId: undefined, managerId: undefined,
    phone: '', address: '', joiningDate: '', salary: undefined, role: 'EMPLOYEE' as 'EMPLOYEE' | 'MANAGER' | 'ADMIN'
  };

  constructor(
    private employeeService: EmployeeService,
    public auth: AuthService
  ) {}

  ngOnInit() {
    this.loadEmployees();
    this.loadDepartments();
    this.loadDesignations();
  }

  loadEmployees() {
    this.employeeService.getAllEmployees().subscribe({
      next: (data) => {
        this.employees.set(data);
        this.filteredEmployees.set(data);
        this.isLoading.set(false);
      },
      error: () => {
        this.employees.set([]);
        this.isLoading.set(false);
      }
    });
  }

  loadDepartments() {
    this.employeeService.getDepartments().subscribe({
      next: (data) => this.departments.set(data),
      error: () => this.departments.set([])
    });
  }

  loadDesignations() {
    this.employeeService.getDesignations().subscribe({
      next: (data) => this.designations.set(data),
      error: () => this.designations.set([])
    });
  }

  onSearch() {
    const term = this.searchTerm.toLowerCase();
    if (!term) {
      this.filteredEmployees.set(this.employees());
    } else {
      this.filteredEmployees.set(
        this.employees().filter(e =>
          e.name?.toLowerCase().includes(term) ||
          e.email?.toLowerCase().includes(term) ||
          e.employeeId?.toLowerCase().includes(term) ||
          e.departmentName?.toLowerCase().includes(term)
        )
      );
    }
  }

  addEmployee() {
    this.employeeService.addEmployee(this.newEmployee).subscribe({
      next: () => {
        this.showAddModal.set(false);
        this.loadEmployees();
        this.resetForm();
      },
      error: () => alert('Failed to add employee')
    });
  }

  deactivate(id: number) {
    if (!confirm('Deactivate this employee?')) return;
    this.employeeService.deactivateEmployee(id).subscribe({
      next: () => this.loadEmployees(),
      error: () => alert('Failed to deactivate')
    });
  }

  reactivate(id: number) {
    this.employeeService.reactivateEmployee(id).subscribe({
      next: () => this.loadEmployees(),
      error: () => alert('Failed to reactivate')
    });
  }

  resetForm() {
    this.newEmployee = {
      firstName: '', lastName: '', email: '', password: '', employeeId: '',
      departmentId: undefined, designationId: undefined, managerId: undefined,
      phone: '', address: '', joiningDate: '', salary: undefined, role: 'EMPLOYEE' as 'EMPLOYEE' | 'MANAGER' | 'ADMIN'
    };
  }

  getInitials(name: string | undefined): string {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
}
